Wii: Mario Strikers Charged Football - Goomba
Ripped by Previous for tMR (http://www.models-resource.com/)