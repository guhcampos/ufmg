here is a black bob-omb from mario 64
the textures are very slightly off but are easy to fix using the origional textures
if you use this please give credit to alec pike
if you have any comments, complaints or compliments 
please contact me at alec.pike@gmail.com