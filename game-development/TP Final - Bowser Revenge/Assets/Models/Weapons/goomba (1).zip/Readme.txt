Here is a mario 64 goomba
if you use this, could you please give credit to Alec Pike
if you have any comments or complaints or need help
with something e-mail me at alec.pike@gmail.com