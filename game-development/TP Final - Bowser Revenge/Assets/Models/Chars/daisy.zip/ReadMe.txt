Wii: Mario Strikers Charged Football - Daisy
Ripped by Previous for tMR (http://www.models-resource.com/)