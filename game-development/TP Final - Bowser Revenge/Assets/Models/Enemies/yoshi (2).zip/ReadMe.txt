Wii: Mario Strikers Charged Football - Yoshi
Ripped by Previous for tMR (http://www.models-resource.com/)