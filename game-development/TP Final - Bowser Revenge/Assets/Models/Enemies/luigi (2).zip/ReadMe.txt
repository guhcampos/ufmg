Wii: Mario Strikers Charged Football - Luigi
Ripped by Previous for tMR (http://www.models-resource.com/)