here is luigi from mario party
please give credit to alec pike when used
if you have a request or need help with the model e-mail me at alec.pike@gmail.com