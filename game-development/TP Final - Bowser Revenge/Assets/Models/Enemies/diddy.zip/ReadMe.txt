Wii: Mario Strikers Charged Football - Diddy Kong
Ripped by Previous for tMR (http://www.models-resource.com/)